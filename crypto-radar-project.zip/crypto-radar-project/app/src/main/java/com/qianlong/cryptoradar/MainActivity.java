package com.qianlong.cryptoradar;
import android.app.*; import android.os.*; import android.graphics.Typeface; import android.widget.*; import org.json.JSONObject; import java.net.*; import java.io.*; import java.util.*; import java.util.concurrent.*;
public class MainActivity extends Activity {
 Handler h=new Handler(Looper.getMainLooper()); ExecutorService io=Executors.newSingleThreadExecutor();
 LinkedHashSet<String> coins=new LinkedHashSet<>(Arrays.asList("BTCUSDT","ETHUSDT","BNBUSDT","SOLUSDT"));
 Map<String,String> px=new HashMap<>(),chg=new HashMap<>(); LinearLayout rows; TextView state; boolean alive=true;
 Runnable tick=new Runnable(){public void run(){if(!alive)return; ArrayList<String> c=new ArrayList<>(coins); io.execute(()->{for(String s:c)try{HttpURLConnection x=(HttpURLConnection)new URL("https://api.binance.com/api/v3/ticker/24hr?symbol="+s).openConnection();x.setConnectTimeout(5000);x.setReadTimeout(5000);if(x.getResponseCode()==200){BufferedReader b=new BufferedReader(new InputStreamReader(x.getInputStream()));StringBuilder z=new StringBuilder();String l;while((l=b.readLine())!=null)z.append(l);JSONObject o=new JSONObject(z.toString());px.put(s,o.optString("lastPrice"));chg.put(s,o.optString("priceChangePercent"));}else px.put(s,"请求失败");x.disconnect();}catch(Exception e){px.put(s,"网络异常");} runOnUiThread(()->{draw();state.setText("行情更新 · "+new java.text.SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date()));});});h.postDelayed(this,3000);}};
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(22,26,22,16);root.setBackgroundColor(0xfff4f6f9);
 TextView t=new TextView(this);t.setText("币价雷达");t.setTextSize(27);t.setTypeface(null,Typeface.BOLD);t.setTextColor(0xff172033);root.addView(t);
 TextView sub=new TextView(this);sub.setText("BINANCE · USDT 现货行情");sub.setTextColor(0xff64748b);root.addView(sub);
 state=new TextView(this);state.setText("正在连接行情…");state.setPadding(0,14,0,10);root.addView(state);
 Button add=new Button(this);add.setText("＋ 添加币种");add.setOnClickListener(v->addCoin());root.addView(add);
 ScrollView sc=new ScrollView(this);rows=new LinearLayout(this);rows.setOrientation(1);sc.addView(rows);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
 TextView foot=new TextView(this);foot.setText("每 3 秒刷新 · Binance 公共行情");foot.setTextSize(11);foot.setTextColor(0xff94a3b8);root.addView(foot);setContentView(root);draw();h.post(tick);}
 void addCoin(){EditText e=new EditText(this);e.setSingleLine(true);e.setHint("输入 BTC 或 BTCUSDT");new AlertDialog.Builder(this).setTitle("添加 USDT 交易对").setView(e).setPositiveButton("添加",(d,w)->{String s=e.getText().toString().trim().toUpperCase(Locale.ROOT).replace(" ","");if(!s.endsWith("USDT"))s+="USDT";if(!s.matches("[A-Z0-9]{4,20}")){Toast.makeText(this,"格式不正确",0).show();return;}coins.add(s);draw();}).setNegativeButton("取消",null).show();}
 void draw(){if(rows==null)return;rows.removeAllViews();for(String s:new ArrayList<>(coins)){LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(16,12,16,8);card.setBackgroundColor(-1);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,10);card.setLayoutParams(cp);
 TextView n=new TextView(this);n.setText(s);n.setTypeface(null,1);n.setTextColor(0xff1e293b);n.setTextSize(15);
 TextView p=new TextView(this);p.setText("价格  "+px.getOrDefault(s,"加载中…"));p.setTextSize(19);p.setTextColor(0xff0f172a);
 String c=chg.getOrDefault(s,"--");TextView q=new TextView(this);q.setText("24h涨跌  "+c+"%");try{q.setTextColor(Double.parseDouble(c)>=0?0xff16a34a:0xffdc2626);}catch(Exception ex){q.setTextColor(0xff64748b);}
 Button del=new Button(this);del.setText("删除 "+s);del.setOnClickListener(v->{coins.remove(s);draw();});card.addView(n);card.addView(p);card.addView(q);card.addView(del);rows.addView(card);}}
 protected void onDestroy(){alive=false;h.removeCallbacks(tick);io.shutdownNow();super.onDestroy();}
}